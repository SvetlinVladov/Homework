-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2014 at 09:58 AM
-- Server version: 5.1.62
-- PHP Version: 5.3.5-1ubuntu7.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subdsubd`
--

-- --------------------------------------------------------

--
-- Table structure for table `Article`
--

CREATE TABLE IF NOT EXISTS `Article` (
  `created_on` date DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `many_user_id` int(11) NOT NULL,
  PRIMARY KEY (`article_id`),
  KEY `many_user_id` (`many_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Article`
--

INSERT INTO `Article` (`created_on`, `url`, `published_on`, `article_id`, `many_user_id`) VALUES
('1995-07-07', 'vdsfsdfs', '1995-07-07', 1, 1),
('1995-07-08', 'fdfsdfsdfs', '1995-07-08', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Category_part1`
--

CREATE TABLE IF NOT EXISTS `Category_part1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Category_part1`
--

INSERT INTO `Category_part1` (`id`, `created_by`) VALUES
(1, 'this'),
(2, 'to');

-- --------------------------------------------------------

--
-- Table structure for table `Category_part2`
--

CREATE TABLE IF NOT EXISTS `Category_part2` (
  `description` varchar(50) DEFAULT NULL,
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `many_article_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `many_article_id` (`many_article_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Category_part2`
--

INSERT INTO `Category_part2` (`description`, `category_id`, `many_article_id`) VALUES
('fsdfsd', 1, 1),
('gfhfghhg', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Tag`
--

CREATE TABLE IF NOT EXISTS `Tag` (
  `second_priority` float DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Tag`
--

INSERT INTO `Tag` (`second_priority`, `priority`, `tag_id`) VALUES
(15.27, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `age` int(11) DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`age`, `picture_url`, `income`, `user_id`) VALUES
(7, 'miss', 13.43, 1),
(5, 'out', 12.43, 2);
